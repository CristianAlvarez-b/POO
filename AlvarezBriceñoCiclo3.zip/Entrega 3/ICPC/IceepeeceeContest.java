import java.util.*;


/**
 * Write a description of class IceepeeceeContest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class IceepeeceeContest
{
    private static Iceepeecee iceepeecee;
    static final double PI = Math.PI;
    
    public static Number solve(Number[][][] islands, Number[][][] flights) {
        Iceepeecee iceepeecee = new Iceepeecee(islands, flights);
        String[] allIslands = new String[islands.length];
        String[] temporal = new String[islands.length];
        allIslands = iceepeecee.islands();
        Arrays.sort(allIslands);
        double lo = 0.0;
        double hi = 90; 
        double best = -1;
        for (int rep = 0; rep < 64; rep++) {
            double th = (hi + lo) / 2;
            iceepeecee.photograph(th); 
            temporal = iceepeecee.observedIslands();
            Arrays.sort(temporal);
            boolean areEqual = Arrays.equals(allIslands, temporal);
            if (areEqual) {
                hi = th;
                best = th;
            } else {
                lo = th;
            }
        }
    
        if (best == -1) {
            System.out.println("Impossible");
            return -1;
        } else {
            Number theta = (best);
            return theta;
        }
    }
    
    public static void simulate(Number[][][] islands, Number[][][]fligths){
        iceepeecee = new Iceepeecee(islands, fligths);
        String [] allIslands = new String[islands.length];
        String [] temporal = new String[islands.length];
        allIslands = iceepeecee.islands();
        Arrays.sort(allIslands);
        double lo = 0.0;
        double hi = 90;
        double best = -1;
        for(int rep = 0; rep < 64; rep++){
            double th = (hi + lo) / 2;
            iceepeecee.makeInvisible(); 
            iceepeecee.photograph(th);
            temporal = iceepeecee.observedIslands();
            Arrays.sort(temporal);
            iceepeecee.makeVisible();
            boolean areEqual = Arrays.equals(allIslands, temporal);
            if(areEqual){
                hi = th; 
                best = th;
            }else{
                lo = th;
            }
        }
        
        if(hi == PI/2){
           iceepeecee.makeInvisible(); 
        }else{
           iceepeecee.makeInvisible(); 
           iceepeecee.photograph(best);
           iceepeecee.makeVisible();
        }
    }
}

