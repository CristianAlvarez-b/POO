package domain;

public final class Food implements Entity {
    public void act(){
        
    }
}


