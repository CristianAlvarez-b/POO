package domain;

import java.io.Serializable;

public final class Food implements Entity, Serializable {
    public void act(){
        
    }
}


