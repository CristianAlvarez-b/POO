package domain;
import java.awt.*;
public class Heavy extends Stone{
    public Heavy(Color color) {
        super(color);
        this.value = 2;
    }
}
