package domain;

public class LimitedStones extends Board{

    public LimitedStones(int rows, int columns) throws Exception {
        super(rows, columns, 0);
    }
}
