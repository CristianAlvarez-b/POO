package domain;
public abstract class Machine extends Player{
    public abstract void play() throws Exception;
}
