package domain;

public class QuickTime extends Board{
    public QuickTime(int rows, int columns, int specialStonesPercentage, int timeLimit) throws Exception {
        super(rows, columns, specialStonesPercentage);
    }
}
