package ICPC;
/**
 * Write a description of class IceepeeceeException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class IceepeeceeException extends Exception
{
    /**
     * Constructor for objects of class IceepeeceeException
     */
    public IceepeeceeException(String mensaje) {
        super(mensaje);
    }
}
